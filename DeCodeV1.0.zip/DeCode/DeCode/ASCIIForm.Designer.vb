﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ASCIIForm
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請勿使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ASCIIForm))
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.Firsttop = New System.Windows.Forms.ToolStripMenuItem()
        Me.Decode = New System.Windows.Forms.ToolStripMenuItem()
        Me.Author = New System.Windows.Forms.ToolStripMenuItem()
        Me.allcode = New System.Windows.Forms.ToolStripMenuItem()
        Me.DecimalChange = New System.Windows.Forms.ToolStripMenuItem()
        Me.ASCIICode = New System.Windows.Forms.ToolStripMenuItem()
        Me.BaseCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.ROTCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.CaesarCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.VigenereCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.LeftTextBox = New System.Windows.Forms.TextBox()
        Me.Leftchoice = New System.Windows.Forms.ListBox()
        Me.Rightchoice = New System.Windows.Forms.ListBox()
        Me.LeftText = New System.Windows.Forms.Label()
        Me.RightTextBox = New System.Windows.Forms.TextBox()
        Me.RightText = New System.Windows.Forms.Label()
        Me.Change = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.MenuStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Firsttop, Me.Decode, Me.Author, Me.allcode})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(584, 24)
        Me.MenuStrip2.TabIndex = 4
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'Firsttop
        '
        Me.Firsttop.Name = "Firsttop"
        Me.Firsttop.Size = New System.Drawing.Size(43, 20)
        Me.Firsttop.Text = "首頁"
        '
        'Decode
        '
        Me.Decode.Name = "Decode"
        Me.Decode.Size = New System.Drawing.Size(72, 20)
        Me.Decode.Text = "編碼/解碼"
        '
        'Author
        '
        Me.Author.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.Author.Name = "Author"
        Me.Author.Size = New System.Drawing.Size(43, 20)
        Me.Author.Text = "作者"
        '
        'allcode
        '
        Me.allcode.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DecimalChange, Me.ASCIICode, Me.BaseCode, Me.ROTCode, Me.CaesarCode, Me.VigenereCode})
        Me.allcode.Name = "allcode"
        Me.allcode.Size = New System.Drawing.Size(67, 20)
        Me.allcode.Text = "各碼解析"
        '
        'DecimalChange
        '
        Me.DecimalChange.Name = "DecimalChange"
        Me.DecimalChange.Size = New System.Drawing.Size(165, 22)
        Me.DecimalChange.Text = "Decimal"
        '
        'ASCIICode
        '
        Me.ASCIICode.Name = "ASCIICode"
        Me.ASCIICode.Size = New System.Drawing.Size(165, 22)
        Me.ASCIICode.Text = "ASCII code"
        '
        'BaseCode
        '
        Me.BaseCode.Name = "BaseCode"
        Me.BaseCode.Size = New System.Drawing.Size(165, 22)
        Me.BaseCode.Text = "Base code"
        '
        'ROTCode
        '
        Me.ROTCode.Name = "ROTCode"
        Me.ROTCode.Size = New System.Drawing.Size(165, 22)
        Me.ROTCode.Text = "ROT code"
        '
        'CaesarCode
        '
        Me.CaesarCode.Name = "CaesarCode"
        Me.CaesarCode.Size = New System.Drawing.Size(165, 22)
        Me.CaesarCode.Text = "Caesar Cipher"
        '
        'VigenereCode
        '
        Me.VigenereCode.Name = "VigenereCode"
        Me.VigenereCode.Size = New System.Drawing.Size(165, 22)
        Me.VigenereCode.Text = "Vigenere Cipher"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 29)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "ASCII"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(110, 38)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(398, 12)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "American Standard Code for Information Interchange - 美國資訊交換標準程式碼"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.Location = New System.Drawing.Point(14, 53)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(211, 13)
        Me.LinkLabel1.TabIndex = 7
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "https://en.wikipedia.org/wiki/ASCII"
        '
        'LeftTextBox
        '
        Me.LeftTextBox.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LeftTextBox.Location = New System.Drawing.Point(0, 103)
        Me.LeftTextBox.Name = "LeftTextBox"
        Me.LeftTextBox.Size = New System.Drawing.Size(199, 27)
        Me.LeftTextBox.TabIndex = 1
        '
        'Leftchoice
        '
        Me.Leftchoice.Cursor = System.Windows.Forms.Cursors.Default
        Me.Leftchoice.FormattingEnabled = True
        Me.Leftchoice.ItemHeight = 12
        Me.Leftchoice.Items.AddRange(New Object() {"2(Binary)", "8(Oct)", "10(Dec)", "16(Hex)", "圖形(Glyph)"})
        Me.Leftchoice.Location = New System.Drawing.Point(115, 136)
        Me.Leftchoice.Name = "Leftchoice"
        Me.Leftchoice.Size = New System.Drawing.Size(84, 64)
        Me.Leftchoice.TabIndex = 9
        '
        'Rightchoice
        '
        Me.Rightchoice.FormattingEnabled = True
        Me.Rightchoice.ItemHeight = 12
        Me.Rightchoice.Items.AddRange(New Object() {"2(Binary)", "8(Oct)", "10(Dec)", "16(Hex)", "圖形(Glyph)"})
        Me.Rightchoice.Location = New System.Drawing.Point(385, 136)
        Me.Rightchoice.Name = "Rightchoice"
        Me.Rightchoice.Size = New System.Drawing.Size(84, 64)
        Me.Rightchoice.TabIndex = 10
        '
        'LeftText
        '
        Me.LeftText.AutoSize = True
        Me.LeftText.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LeftText.Location = New System.Drawing.Point(14, 82)
        Me.LeftText.Name = "LeftText"
        Me.LeftText.Size = New System.Drawing.Size(36, 18)
        Me.LeftText.TabIndex = 11
        Me.LeftText.Text = "left"
        '
        'RightTextBox
        '
        Me.RightTextBox.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RightTextBox.Location = New System.Drawing.Point(385, 103)
        Me.RightTextBox.Name = "RightTextBox"
        Me.RightTextBox.ReadOnly = True
        Me.RightTextBox.Size = New System.Drawing.Size(199, 27)
        Me.RightTextBox.TabIndex = 3
        '
        'RightText
        '
        Me.RightText.AutoSize = True
        Me.RightText.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RightText.Location = New System.Drawing.Point(385, 82)
        Me.RightText.Name = "RightText"
        Me.RightText.Size = New System.Drawing.Size(51, 18)
        Me.RightText.TabIndex = 13
        Me.RightText.Text = "Right"
        '
        'Change
        '
        Me.Change.Font = New System.Drawing.Font("新細明體", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Change.Location = New System.Drawing.Point(205, 103)
        Me.Change.Name = "Change"
        Me.Change.Size = New System.Drawing.Size(174, 42)
        Me.Change.TabIndex = 2
        Me.Change.Text = "轉換" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Change" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Change.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(0, 201)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(584, 159)
        Me.TextBox1.TabIndex = 15
        Me.TextBox1.Text = resources.GetString("TextBox1.Text")
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(237, 54)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(341, 12)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "還有另一個叫EASCII(Extended ASCII - 延伸美國標準資訊交換碼)"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel2.Location = New System.Drawing.Point(236, 66)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(271, 13)
        Me.LinkLabel2.TabIndex = 17
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "https://en.wikipedia.org/wiki/Extended_ASCII"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("標楷體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label4.Location = New System.Drawing.Point(224, 148)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(136, 16)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "ASCII and EASCII"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("標楷體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label5.Location = New System.Drawing.Point(-3, 182)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 16)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "參考表" & Global.Microsoft.VisualBasic.ChrW(13)
        '
        'ASCIIForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(584, 361)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.LinkLabel2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Change)
        Me.Controls.Add(Me.RightText)
        Me.Controls.Add(Me.RightTextBox)
        Me.Controls.Add(Me.LeftText)
        Me.Controls.Add(Me.Rightchoice)
        Me.Controls.Add(Me.Leftchoice)
        Me.Controls.Add(Me.LeftTextBox)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "ASCIIForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cipher v1.0"
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip2 As MenuStrip
    Friend WithEvents Firsttop As ToolStripMenuItem
    Friend WithEvents Decode As ToolStripMenuItem
    Friend WithEvents Author As ToolStripMenuItem
    Friend WithEvents allcode As ToolStripMenuItem
    Friend WithEvents ASCIICode As ToolStripMenuItem
    Friend WithEvents BaseCode As ToolStripMenuItem
    Friend WithEvents ROTCode As ToolStripMenuItem
    Friend WithEvents CaesarCode As ToolStripMenuItem
    Friend WithEvents VigenereCode As ToolStripMenuItem
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents LeftTextBox As TextBox
    Friend WithEvents Leftchoice As ListBox
    Friend WithEvents Rightchoice As ListBox
    Friend WithEvents LeftText As Label
    Friend WithEvents RightTextBox As TextBox
    Friend WithEvents RightText As Label
    Friend WithEvents Change As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents LinkLabel2 As LinkLabel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents DecimalChange As ToolStripMenuItem
End Class
