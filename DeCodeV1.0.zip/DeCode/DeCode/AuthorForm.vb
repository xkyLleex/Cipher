﻿Public Class AuthorForm
    Dim num As Integer
    Dim checkUpDown As Boolean = True
    Dim runcheck As Boolean = True
    Private Sub AuthorForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Environment.Exit(Environment.ExitCode)
        Application.Exit()
    End Sub

    Private Sub Subtraction_Click(sender As Object, e As EventArgs) Handles subtraction.Click
        num -= 1
        If num = -1 Then
            num = 0
        End If
        ProgressBar1.Value = num
        Label6.Text = num & " %"
    End Sub

    Private Sub Addition_Click(sender As Object, e As EventArgs) Handles addition.Click
        num += 1
        If num = 101 Then
            num = 100
        End If
        ProgressBar1.Value = num
        Label6.Text = num & " %"
    End Sub

    Private Sub Clear_Click(sender As Object, e As EventArgs) Handles Clear.Click
        num = 0
        ProgressBar1.Value = num
        Label6.Text = num & " %"
    End Sub

    Private Sub Run_Click(sender As Object, e As EventArgs) Handles Run.Click
        If runcheck Then
            Timer1.Start()
            Run.Text = "看了好煩，停！"
            runcheck = False
        Else
            Timer1.Stop()
            Run.Text = "還是讓它動好了"
            runcheck = True
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If checkUpDown Then
            If num = 100 Then
                checkUpDown = False
            Else
                num += 1
                ProgressBar1.Value = num
                Label6.Text = num & " %"
            End If
        Else
            If num = 0 Then
                checkUpDown = True
            Else
                num -= 1
                ProgressBar1.Value = num
                Label6.Text = num & " %"
            End If
        End If
    End Sub

    Private Sub Buttonconfirm_Click(sender As Object, e As EventArgs) Handles Buttonconfirm.Click
        If TextBox1.Text = "041105-Is-Fat-Guy." Then
            TextBox2.Text = "YOU ARE RIGHT!!!"
            LinkLabel3.Visible = True
        Else
            TextBox1.Text = ""
            TextBox2.Text = "ERROR INPUT"
        End If
    End Sub

    Private Sub ASCIICode_Click(sender As Object, e As EventArgs) Handles ASCIICode.Click
        ASCIIForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub BaseCode_Click(sender As Object, e As EventArgs) Handles BaseCode.Click
        BaseForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub ROTCode_Click(sender As Object, e As EventArgs) Handles ROTCode.Click
        ROTForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub CaesarCode_Click(sender As Object, e As EventArgs) Handles CaesarCode.Click
        CaesarForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub VigenereCode_Click(sender As Object, e As EventArgs) Handles VigenereCode.Click
        VigenereForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Firsttop_Click(sender As Object, e As EventArgs) Handles Firsttop.Click
        FirstForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Decode_Click(sender As Object, e As EventArgs) Handles Decode.Click
        DeCodeForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        System.Diagnostics.Process.Start("https://github.com/xkyLleex/")
    End Sub

    Private Sub DecimalChange_Click(sender As Object, e As EventArgs) Handles DecimalChange.Click
        DecimalForm.Show()
        Reload()
        Me.Hide()
    End Sub
    Sub Reload()
        num = 0
        TextBox1.Text = ""
        TextBox2.Text = ""
        ProgressBar1.Value = num
        Label6.Text = num & " %"
        Run.Text = "點好累，讓他自己跑"
        checkUpDown = True
        runcheck = True
        Timer1.Stop()
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        System.Diagnostics.Process.Start("https://mega.nz/#!GdNE3SwL!ltOlHR6zKsyNYQIiSWnvkUWRjefjLnfseiA1FvCRnjQ")
    End Sub

    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        System.Diagnostics.Process.Start("https://mega.nz/#!CYMQ1IKJ!cufiWgzvKAaUj5TJiHdyBtcjUqWo7yKcjayQN7-bRos")
    End Sub
End Class