﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BaseForm
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請勿使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BaseForm))
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.Firsttop = New System.Windows.Forms.ToolStripMenuItem()
        Me.Decode = New System.Windows.Forms.ToolStripMenuItem()
        Me.Author = New System.Windows.Forms.ToolStripMenuItem()
        Me.allcode = New System.Windows.Forms.ToolStripMenuItem()
        Me.DecimalChange = New System.Windows.Forms.ToolStripMenuItem()
        Me.ASCIICode = New System.Windows.Forms.ToolStripMenuItem()
        Me.BaseCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.ROTCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.CaesarCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.VigenereCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.helptext = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.MenuStrip2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Firsttop, Me.Decode, Me.Author, Me.allcode})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(584, 24)
        Me.MenuStrip2.TabIndex = 4
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'Firsttop
        '
        Me.Firsttop.Name = "Firsttop"
        Me.Firsttop.Size = New System.Drawing.Size(43, 20)
        Me.Firsttop.Text = "首頁"
        '
        'Decode
        '
        Me.Decode.Name = "Decode"
        Me.Decode.Size = New System.Drawing.Size(72, 20)
        Me.Decode.Text = "編碼/解碼"
        '
        'Author
        '
        Me.Author.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.Author.Name = "Author"
        Me.Author.Size = New System.Drawing.Size(43, 20)
        Me.Author.Text = "作者"
        '
        'allcode
        '
        Me.allcode.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DecimalChange, Me.ASCIICode, Me.BaseCode, Me.ROTCode, Me.CaesarCode, Me.VigenereCode})
        Me.allcode.Name = "allcode"
        Me.allcode.Size = New System.Drawing.Size(67, 20)
        Me.allcode.Text = "各碼解析"
        '
        'DecimalChange
        '
        Me.DecimalChange.Name = "DecimalChange"
        Me.DecimalChange.Size = New System.Drawing.Size(165, 22)
        Me.DecimalChange.Text = "Decimal"
        '
        'ASCIICode
        '
        Me.ASCIICode.Name = "ASCIICode"
        Me.ASCIICode.Size = New System.Drawing.Size(165, 22)
        Me.ASCIICode.Text = "ASCII code"
        '
        'BaseCode
        '
        Me.BaseCode.Name = "BaseCode"
        Me.BaseCode.Size = New System.Drawing.Size(165, 22)
        Me.BaseCode.Text = "Base64/32 code"
        '
        'ROTCode
        '
        Me.ROTCode.Name = "ROTCode"
        Me.ROTCode.Size = New System.Drawing.Size(165, 22)
        Me.ROTCode.Text = "ROT code"
        '
        'CaesarCode
        '
        Me.CaesarCode.Name = "CaesarCode"
        Me.CaesarCode.Size = New System.Drawing.Size(165, 22)
        Me.CaesarCode.Text = "Caesar Cipher"
        '
        'VigenereCode
        '
        Me.VigenereCode.Name = "VigenereCode"
        Me.VigenereCode.Size = New System.Drawing.Size(165, 22)
        Me.VigenereCode.Text = "Vigenere Cipher"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(162, 29)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Base64/32"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.Location = New System.Drawing.Point(195, 33)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(68, 18)
        Me.LinkLabel1.TabIndex = 8
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Base64"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel2.Location = New System.Drawing.Point(288, 33)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(68, 18)
        Me.LinkLabel2.TabIndex = 9
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Base32"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(-2, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 12)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "基本原理"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 69)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(527, 128)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 11
        Me.PictureBox1.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(-2, 317)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 12)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Base64索引值"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(0, 333)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(374, 210)
        Me.TextBox1.TabIndex = 13
        Me.TextBox1.Text = resources.GetString("TextBox1.Text")
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(-2, 546)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(242, 12)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Base32索引值用的是:RFC 4648 Base32 alphabet"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(0, 561)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(374, 114)
        Me.TextBox2.TabIndex = 15
        Me.TextBox2.Text = resources.GetString("TextBox2.Text")
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(0, 190)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(527, 113)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 16
        Me.PictureBox2.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(100, 305)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(427, 24)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Base32跟上圖類似，差在索引值不同跟長度不同(Base64為6位元、Base32為5位元)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "後面只要是補出的0，字元就會是=而不是A"
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(474, 389)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(53, 27)
        Me.TextBox3.TabIndex = 19
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(380, 389)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(53, 27)
        Me.TextBox4.TabIndex = 20
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(416, 374)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(77, 12)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "數值查詢字元"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(382, 355)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(58, 16)
        Me.CheckBox1.TabIndex = 22
        Me.CheckBox1.Text = "Base64"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(474, 355)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(58, 16)
        Me.CheckBox2.TabIndex = 23
        Me.CheckBox2.Text = "Base32"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'helptext
        '
        Me.helptext.AutoSize = True
        Me.helptext.ForeColor = System.Drawing.Color.Red
        Me.helptext.Location = New System.Drawing.Point(380, 419)
        Me.helptext.Name = "helptext"
        Me.helptext.Size = New System.Drawing.Size(26, 12)
        Me.helptext.TabIndex = 24
        Me.helptext.Text = "Text"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(382, 662)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(137, 12)
        Me.Label5.TabIndex = 25
        Me.Label5.Text = "若想知道更多，聯絡我！"
        '
        'BaseForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(601, 361)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.helptext)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.LinkLabel2)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "BaseForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cipher v1.0"
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip2 As MenuStrip
    Friend WithEvents Firsttop As ToolStripMenuItem
    Friend WithEvents Decode As ToolStripMenuItem
    Friend WithEvents Author As ToolStripMenuItem
    Friend WithEvents allcode As ToolStripMenuItem
    Friend WithEvents ASCIICode As ToolStripMenuItem
    Friend WithEvents BaseCode As ToolStripMenuItem
    Friend WithEvents ROTCode As ToolStripMenuItem
    Friend WithEvents CaesarCode As ToolStripMenuItem
    Friend WithEvents VigenereCode As ToolStripMenuItem
    Friend WithEvents DecimalChange As ToolStripMenuItem
    Friend WithEvents Label1 As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents LinkLabel2 As LinkLabel
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents helptext As Label
    Friend WithEvents Label5 As Label
End Class
