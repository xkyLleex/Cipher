﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DeCodeForm
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請勿使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DeCodeForm))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.firsttop = New System.Windows.Forms.ToolStripMenuItem()
        Me.decodeselect = New System.Windows.Forms.ToolStripMenuItem()
        Me.Author = New System.Windows.Forms.ToolStripMenuItem()
        Me.allcode = New System.Windows.Forms.ToolStripMenuItem()
        Me.DecimalChange = New System.Windows.Forms.ToolStripMenuItem()
        Me.ASCIICode = New System.Windows.Forms.ToolStripMenuItem()
        Me.BaseCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.ROTCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.CaesarCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.VigenereCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.code = New System.Windows.Forms.TextBox()
        Me.decode = New System.Windows.Forms.Button()
        Me.encode = New System.Windows.Forms.Button()
        Me.showcode = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.key = New System.Windows.Forms.TextBox()
        Me.keytext = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.firsttop, Me.decodeselect, Me.Author, Me.allcode})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(668, 24)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'firsttop
        '
        Me.firsttop.Name = "firsttop"
        Me.firsttop.Size = New System.Drawing.Size(43, 20)
        Me.firsttop.Text = "首頁"
        '
        'decodeselect
        '
        Me.decodeselect.Name = "decodeselect"
        Me.decodeselect.Size = New System.Drawing.Size(72, 20)
        Me.decodeselect.Text = "編碼/解碼"
        '
        'Author
        '
        Me.Author.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.Author.Name = "Author"
        Me.Author.Size = New System.Drawing.Size(43, 20)
        Me.Author.Text = "作者"
        '
        'allcode
        '
        Me.allcode.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DecimalChange, Me.ASCIICode, Me.BaseCode, Me.ROTCode, Me.CaesarCode, Me.VigenereCode})
        Me.allcode.Name = "allcode"
        Me.allcode.Size = New System.Drawing.Size(67, 20)
        Me.allcode.Text = "各碼解析"
        '
        'DecimalChange
        '
        Me.DecimalChange.Name = "DecimalChange"
        Me.DecimalChange.Size = New System.Drawing.Size(165, 22)
        Me.DecimalChange.Text = "Decimal"
        '
        'ASCIICode
        '
        Me.ASCIICode.Name = "ASCIICode"
        Me.ASCIICode.Size = New System.Drawing.Size(165, 22)
        Me.ASCIICode.Text = "ASCII code"
        '
        'BaseCode
        '
        Me.BaseCode.Name = "BaseCode"
        Me.BaseCode.Size = New System.Drawing.Size(165, 22)
        Me.BaseCode.Text = "Base code"
        '
        'ROTCode
        '
        Me.ROTCode.Name = "ROTCode"
        Me.ROTCode.Size = New System.Drawing.Size(165, 22)
        Me.ROTCode.Text = "ROT code"
        '
        'CaesarCode
        '
        Me.CaesarCode.Name = "CaesarCode"
        Me.CaesarCode.Size = New System.Drawing.Size(165, 22)
        Me.CaesarCode.Text = "Caesar Cipher"
        '
        'VigenereCode
        '
        Me.VigenereCode.Name = "VigenereCode"
        Me.VigenereCode.Size = New System.Drawing.Size(165, 22)
        Me.VigenereCode.Text = "Vigenere Cipher"
        '
        'ListBox1
        '
        Me.ListBox1.Font = New System.Drawing.Font("細明體-ExtB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Items.AddRange(New Object() {"Base64", "Base32(RCF4648)", "ROT13", "ROT18", "ROT47", "Caesar Cipher", "Vigenere Cipher", "SHA-1", "SHA-2 SHA256", "SHA-2 SHA384", "SHA-2 SHA512", "MD5"})
        Me.ListBox1.Location = New System.Drawing.Point(0, 119)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(171, 196)
        Me.ListBox1.TabIndex = 3
        '
        'code
        '
        Me.code.AllowDrop = True
        Me.code.Font = New System.Drawing.Font("細明體-ExtB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.code.Location = New System.Drawing.Point(177, 91)
        Me.code.MaxLength = 0
        Me.code.Multiline = True
        Me.code.Name = "code"
        Me.code.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.code.Size = New System.Drawing.Size(479, 109)
        Me.code.TabIndex = 6
        '
        'decode
        '
        Me.decode.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.decode.Location = New System.Drawing.Point(177, 29)
        Me.decode.Name = "decode"
        Me.decode.Size = New System.Drawing.Size(123, 39)
        Me.decode.TabIndex = 7
        Me.decode.Text = "Decode"
        Me.decode.UseVisualStyleBackColor = True
        '
        'encode
        '
        Me.encode.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.encode.Location = New System.Drawing.Point(533, 29)
        Me.encode.Name = "encode"
        Me.encode.Size = New System.Drawing.Size(123, 39)
        Me.encode.TabIndex = 8
        Me.encode.Text = "Encode"
        Me.encode.UseVisualStyleBackColor = True
        '
        'showcode
        '
        Me.showcode.Font = New System.Drawing.Font("細明體-ExtB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.showcode.Location = New System.Drawing.Point(177, 206)
        Me.showcode.MaxLength = 0
        Me.showcode.Multiline = True
        Me.showcode.Name = "showcode"
        Me.showcode.ReadOnly = True
        Me.showcode.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.showcode.Size = New System.Drawing.Size(479, 109)
        Me.showcode.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoEllipsis = True
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(361, 29)
        Me.Label1.MaximumSize = New System.Drawing.Size(150, 200)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(111, 29)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Base64"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("標楷體", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label2.Location = New System.Drawing.Point(0, 318)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(453, 11)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
        '
        'key
        '
        Me.key.Location = New System.Drawing.Point(2, 91)
        Me.key.Name = "key"
        Me.key.Size = New System.Drawing.Size(169, 22)
        Me.key.TabIndex = 12
        '
        'keytext
        '
        Me.keytext.AutoSize = True
        Me.keytext.Location = New System.Drawing.Point(0, 76)
        Me.keytext.Name = "keytext"
        Me.keytext.Size = New System.Drawing.Size(39, 12)
        Me.keytext.TabIndex = 13
        Me.keytext.Text = "keytext"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("標楷體", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(0, 341)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(453, 11)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
        '
        'DeCodeForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(668, 361)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.keytext)
        Me.Controls.Add(Me.key)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.showcode)
        Me.Controls.Add(Me.encode)
        Me.Controls.Add(Me.decode)
        Me.Controls.Add(Me.code)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "DeCodeForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cipher v1.0"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents firsttop As ToolStripMenuItem
    Friend WithEvents decodeselect As ToolStripMenuItem
    Friend WithEvents Author As ToolStripMenuItem
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents code As TextBox
    Friend WithEvents decode As Button
    Friend WithEvents encode As Button
    Friend WithEvents showcode As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents key As TextBox
    Friend WithEvents keytext As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents allcode As ToolStripMenuItem
    Friend WithEvents ASCIICode As ToolStripMenuItem
    Friend WithEvents ROTCode As ToolStripMenuItem
    Friend WithEvents BaseCode As ToolStripMenuItem
    Friend WithEvents CaesarCode As ToolStripMenuItem
    Friend WithEvents VigenereCode As ToolStripMenuItem
    Friend WithEvents DecimalChange As ToolStripMenuItem
End Class
