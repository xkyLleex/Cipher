﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CaesarForm
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請勿使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CaesarForm))
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.Firsttop = New System.Windows.Forms.ToolStripMenuItem()
        Me.Decode = New System.Windows.Forms.ToolStripMenuItem()
        Me.Author = New System.Windows.Forms.ToolStripMenuItem()
        Me.allcode = New System.Windows.Forms.ToolStripMenuItem()
        Me.DecimalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ASCIICode = New System.Windows.Forms.ToolStripMenuItem()
        Me.BaseCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.ROTCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.CaesarCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.VigenereCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.MenuStrip2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Firsttop, Me.Decode, Me.Author, Me.allcode})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(584, 24)
        Me.MenuStrip2.TabIndex = 4
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'Firsttop
        '
        Me.Firsttop.Name = "Firsttop"
        Me.Firsttop.Size = New System.Drawing.Size(43, 20)
        Me.Firsttop.Text = "首頁"
        '
        'Decode
        '
        Me.Decode.Name = "Decode"
        Me.Decode.Size = New System.Drawing.Size(72, 20)
        Me.Decode.Text = "編碼/解碼"
        '
        'Author
        '
        Me.Author.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.Author.Name = "Author"
        Me.Author.Size = New System.Drawing.Size(43, 20)
        Me.Author.Text = "作者"
        '
        'allcode
        '
        Me.allcode.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DecimalToolStripMenuItem, Me.ASCIICode, Me.BaseCode, Me.ROTCode, Me.CaesarCode, Me.VigenereCode})
        Me.allcode.Name = "allcode"
        Me.allcode.Size = New System.Drawing.Size(67, 20)
        Me.allcode.Text = "各碼解析"
        '
        'DecimalToolStripMenuItem
        '
        Me.DecimalToolStripMenuItem.Name = "DecimalToolStripMenuItem"
        Me.DecimalToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.DecimalToolStripMenuItem.Text = "Decimal"
        '
        'ASCIICode
        '
        Me.ASCIICode.Name = "ASCIICode"
        Me.ASCIICode.Size = New System.Drawing.Size(165, 22)
        Me.ASCIICode.Text = "ASCII code"
        '
        'BaseCode
        '
        Me.BaseCode.Name = "BaseCode"
        Me.BaseCode.Size = New System.Drawing.Size(165, 22)
        Me.BaseCode.Text = "Base code"
        '
        'ROTCode
        '
        Me.ROTCode.Name = "ROTCode"
        Me.ROTCode.Size = New System.Drawing.Size(165, 22)
        Me.ROTCode.Text = "ROT code"
        '
        'CaesarCode
        '
        Me.CaesarCode.Name = "CaesarCode"
        Me.CaesarCode.Size = New System.Drawing.Size(165, 22)
        Me.CaesarCode.Text = "Caesar Cipher"
        '
        'VigenereCode
        '
        Me.VigenereCode.Name = "VigenereCode"
        Me.VigenereCode.Size = New System.Drawing.Size(165, 22)
        Me.VigenereCode.Text = "Vigenere Cipher"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(104, 29)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Caesar"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.Location = New System.Drawing.Point(132, 35)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(108, 16)
        Me.LinkLabel1.TabIndex = 8
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Caesar-tw-wiki"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel2.Location = New System.Drawing.Point(282, 35)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(107, 16)
        Me.LinkLabel2.TabIndex = 9
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Caesar-en-wiki"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 56)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(320, 135)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 194)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(378, 12)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "當偏移量是3的時候，所有的字母A將被替換成D，B變成E，以此類推。"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("標楷體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 246)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 16)
        Me.Label3.TabIndex = 12
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("標楷體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(12, 220)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(545, 27)
        Me.TextBox1.TabIndex = 14
        Me.TextBox1.Text = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("標楷體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(12, 309)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(545, 27)
        Me.TextBox2.TabIndex = 15
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(45, 259)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 16
        Me.Button1.Text = "轉換"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(125, 264)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 12)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "偏移量"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(173, 259)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(67, 22)
        Me.TextBox3.TabIndex = 18
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Red
        Me.Label5.Location = New System.Drawing.Point(42, 285)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 16)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "Text"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.Location = New System.Drawing.Point(262, 262)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(152, 20)
        Me.CheckBox1.TabIndex = 20
        Me.CheckBox1.Text = "Custom(自訂字串)"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(440, 257)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(117, 27)
        Me.Button2.TabIndex = 21
        Me.Button2.Text = "放上全英文(26字)"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("標楷體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label7.Location = New System.Drawing.Point(338, 56)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(248, 80)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "基本凱薩密碼都是用英文來加密，" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "在編碼/解碼那" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "如果輸入非英文的話會保留" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "破解密碼極為簡單"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("標楷體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(338, 148)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 24
        Me.Label6.Text = "text"
        '
        'CaesarForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(584, 361)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.LinkLabel2)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.MenuStrip2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "CaesarForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cipher v1.0"
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip2 As MenuStrip
    Friend WithEvents Firsttop As ToolStripMenuItem
    Friend WithEvents Decode As ToolStripMenuItem
    Friend WithEvents Author As ToolStripMenuItem
    Friend WithEvents allcode As ToolStripMenuItem
    Friend WithEvents ASCIICode As ToolStripMenuItem
    Friend WithEvents BaseCode As ToolStripMenuItem
    Friend WithEvents ROTCode As ToolStripMenuItem
    Friend WithEvents CaesarCode As ToolStripMenuItem
    Friend WithEvents VigenereCode As ToolStripMenuItem
    Friend WithEvents Label2 As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents LinkLabel2 As LinkLabel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents DecimalToolStripMenuItem As ToolStripMenuItem
End Class
