﻿Public Class FirstForm
    Dim textx, texty As Integer
    Dim stopstart As Boolean
    Private Sub FirstForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Environment.Exit(Environment.ExitCode)
        Application.Exit()
    End Sub
    Private Sub ASCIICode_Click(sender As Object, e As EventArgs) Handles ASCIICode.Click
        ASCIIForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub BaseCode_Click(sender As Object, e As EventArgs) Handles BaseCode.Click
        BaseForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub ROTCode_Click(sender As Object, e As EventArgs) Handles ROTCode.Click
        ROTForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub CaesarCode_Click(sender As Object, e As EventArgs) Handles CaesarCode.Click
        CaesarForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub VigenereCode_Click(sender As Object, e As EventArgs) Handles VigenereCode.Click
        VigenereForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Decode_Click(sender As Object, e As EventArgs) Handles Decode.Click
        DeCodeForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Author_Click(sender As Object, e As EventArgs) Handles Author.Click
        AuthorForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles run.Click
        If stopstart Then
            Reload()
        Else
            Timer1.Start()
            run.Text = "Stop"
            stopstart = True
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Downtext.Location = New Point(textx, texty)
        textx -= 1
        If textx = -260 Then
            Downtext.Location = New Point(600, texty)
            textx = 600
        End If
    End Sub

    Private Sub DecimalChange_Click(sender As Object, e As EventArgs) Handles DecimalChange.Click
        DecimalForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub FirstForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        textx = Downtext.Location.X
        texty = Downtext.Location.Y
        Timer1.Start()
        stopstart = True
    End Sub

    Sub Reload()
        Timer1.Stop()
        run.Text = "Start"
        stopstart = False
    End Sub
End Class