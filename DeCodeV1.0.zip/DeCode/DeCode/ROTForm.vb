﻿Public Class ROTForm
    Private Sub ROTForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Environment.Exit(Environment.ExitCode)
        Application.Exit()
    End Sub
    Private Sub ASCIICode_Click(sender As Object, e As EventArgs) Handles ASCIICode.Click
        ASCIIForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub BaseCode_Click(sender As Object, e As EventArgs) Handles BaseCode.Click
        BaseForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub CaesarCode_Click(sender As Object, e As EventArgs) Handles CaesarCode.Click
        CaesarForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub VigenereCode_Click(sender As Object, e As EventArgs) Handles VigenereCode.Click
        VigenereForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Author_Click(sender As Object, e As EventArgs) Handles Author.Click
        AuthorForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Firsttop_Click(sender As Object, e As EventArgs) Handles Firsttop.Click
        FirstForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Decode_Click(sender As Object, e As EventArgs) Handles Decode.Click
        DeCodeForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub DecimalChange_Click(sender As Object, e As EventArgs) Handles DecimalChange.Click
        DecimalForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        System.Diagnostics.Process.Start("https://en.wikipedia.org/wiki/ROT13")
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        TextBox3.Text = ""
        Label4.Text = ""
        If Textchoice.Text = "ROT13" Then
            Dim rot13U As String = "ABCDEFGHIJKLMabcdefghijklm"
            Dim rot13D As String = "NOPQRSTUVWXYZnopqrstuvwxyz"
            For num As Integer = 0 To rot13U.Length - 1
                If rot13U(num) = TextBox2.Text Then
                    TextBox3.Text = rot13D(num)
                    Exit For
                End If
                If rot13D(num) = TextBox2.Text Then
                    TextBox3.Text = rot13U(num)
                    Exit For
                End If
            Next
        ElseIf Textchoice.Text = "ROT18" Then
            Dim rot18U As String = "ABCDEFGHIJKLMNOPQRabcdefghijklmnopqr"
            Dim rot18D As String = "STUVWXYZ0123456789stuvwxyz0123456789"
            For num As Integer = 0 To rot18U.Length - 1
                If rot18U(num) = TextBox2.Text Then
                    TextBox3.Text = rot18D(num)
                    Exit For
                End If
                If rot18D(num) = TextBox2.Text Then
                    TextBox3.Text = rot18U(num)
                    Exit For
                End If
            Next
        ElseIf Textchoice.Text = "ROT47" Then
            Dim rot47U As String = "!" + Chr(34) + "#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNO"
            Dim rot47D As String = "PQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~"
            For num As Integer = 0 To rot47U.Length - 1
                If rot47U(num) = TextBox2.Text Then
                    TextBox3.Text = rot47D(num)
                    Exit For
                End If
                If rot47D(num) = TextBox2.Text Then
                    TextBox3.Text = rot47U(num)
                    Exit For
                End If
            Next
        End If
        If TextBox2.Text <> "" And TextBox3.Text = "" And Textchoice.Text <> "Choice one" Then
            TextBox3.Text = "Error"
            Label4.Text = "字元錯誤！"
        End If
        If Textchoice.Text = "Choice one" And TextBox2.Text <> "" Then
            TextBox3.Text = "Error"
            Label4.Text = "請選擇轉換方式！"
        End If
    End Sub

    Private Sub ROTForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reload()
    End Sub
    Sub Reload()
        Label4.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        Textchoice.Text = "Choice one"
    End Sub

    Private Sub Textchoice_SelectedItemChanged(sender As Object, e As EventArgs) Handles Textchoice.SelectedItemChanged
        Label4.Text = ""
        TextBox2.Text = ""
    End Sub
End Class