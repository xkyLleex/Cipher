﻿Public Class ASCIIForm
    Private Sub ASCIIForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Environment.Exit(Environment.ExitCode)
        Application.Exit()
    End Sub
    Private Sub Author_Click(sender As Object, e As EventArgs) Handles Author.Click
        AuthorForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub BaseCode_Click(sender As Object, e As EventArgs) Handles BaseCode.Click
        BaseForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub ROTCode_Click(sender As Object, e As EventArgs) Handles ROTCode.Click
        ROTForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub CaesarCode_Click(sender As Object, e As EventArgs) Handles CaesarCode.Click
        CaesarForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub VigenereCode_Click(sender As Object, e As EventArgs) Handles VigenereCode.Click
        VigenereForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Firsttop_Click(sender As Object, e As EventArgs) Handles Firsttop.Click
        FirstForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Decode_Click(sender As Object, e As EventArgs) Handles Decode.Click
        DeCodeForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        System.Diagnostics.Process.Start("https://en.wikipedia.org/wiki/ASCII")
    End Sub

    Private Sub ASCIIForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reload()
    End Sub

    Private Sub Leftchoice_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Leftchoice.SelectedIndexChanged
        Select Case Leftchoice.Text
            Case "2(Binary)"
                LeftText.Text = "2-二進位(Binary)"
            Case "8(Oct)"
                LeftText.Text = "8-八進位(Oct)"
            Case "10(Dec)"
                LeftText.Text = "10-十進位(Dec)"
            Case "16(Hex)"
                LeftText.Text = "16-十六進位(Hex)"
            Case "圖形(Glyph)"
                LeftText.Text = "Glyph-圖形"
        End Select
    End Sub

    Private Sub Rightchoice_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Rightchoice.SelectedIndexChanged
        Select Case Rightchoice.Text
            Case "2(Binary)"
                RightText.Text = "2-二進位(Binary)"
            Case "8(Oct)"
                RightText.Text = "8-八進位(Oct)"
            Case "10(Dec)"
                RightText.Text = "10-十進位(Dec)"
            Case "16(Hex)"
                RightText.Text = "16-十六進位(Hex)"
            Case "圖形(Glyph)"
                RightText.Text = "Glyph-圖形"
        End Select
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        System.Diagnostics.Process.Start("https://en.wikipedia.org/wiki/Extended_ASCII")
    End Sub

    Private Sub Change_Click(sender As Object, e As EventArgs) Handles Change.Click
        If LeftText.Text = "" Or RightText.Text = "" Then
            MsgBox("請選擇轉換方式" + vbCrLf + "(兩種都要)", vbOKOnly, "System")
        Else
            If LeftTextBox.Text = "" Then
                MsgBox("請輸入Code進去", vbOKOnly, "System")
            Else
                RightTextBox.Text = AsciiChange(LeftTextBox.Text)
            End If
        End If
    End Sub

    Function AsciiChange(ByVal str As String) As String
        Dim text As Integer
        Dim decode As String = ""
        Dim eascii As String = "¡¢£¤¥¦§¨©ª«¬ ®¯°±²³´µ¶·¸¹º»¼½¾¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõö÷øùúûüýþÿ"
        Select Case LeftText.Text 'to dec(10)
            Case "2-二進位(Binary)"
                Try
                    text = Convert.ToInt32(str, 2)
                Catch ex As Exception
                    MsgBox(ex.Message, vbOKOnly, "System")
                    Return "Error"
                End Try
            Case "8-八進位(Oct)"
                Try
                    text = Convert.ToInt32(str, 8)
                Catch ex As Exception
                    MsgBox(ex.Message, vbOKOnly, "System")
                    Return "Error"
                End Try
            Case "10-十進位(Dec)"
                Try
                    text = Convert.ToInt32(str, 10)
                Catch ex As Exception
                    MsgBox(ex.Message, vbOKOnly, "System")
                    Return "Error"
                End Try
            Case "16-十六進位(Hex)"
                Try
                    text = Convert.ToInt32(str, 16)
                Catch ex As Exception
                    MsgBox(ex.Message, vbOKOnly, "System")
                    Return "Error"
                End Try
            Case "Glyph-圖形"
                Try
                    text = Asc(str)
                    For count As Integer = 0 To eascii.Length - 1
                        If str = eascii(count) Then
                            text = count + 160
                            Exit For
                        End If
                    Next
                Catch ex As Exception
                    MsgBox(ex.Message, vbOKOnly, "System")
                    Return "Error"
                End Try
        End Select
        Select Case RightText.Text 'to any decimal(進制)
            Case "2-二進位(Binary)"
                decode = Convert.ToString(text, 2)
            Case "8-八進位(Oct)"
                decode = Convert.ToString(text, 8)
            Case "10-十進位(Dec)"
                decode = text.ToString
            Case "16-十六進位(Hex)"
                decode = Convert.ToString(text, 16)
            Case "Glyph-圖形"
                If text > 159 And text < 256 Then
                    Dim num As Integer = text - 160
                    If num = 0 Then
                        decode = "NBSP(不換行空格)"
                    ElseIf num = 13 Then
                        decode = "SHY(選擇性連接號)"
                    Else
                        decode = eascii(num)
                    End If
                ElseIf (text >= 0 And text < 32) Or text = 127 Then
                    Dim controlchr() As String = {"NUL", "SOH", "STX", "ETX", "EOT", "ENQ", "ACK", "BEL",
                                                  "BS", "HT", "LF", "VT", "FF", "CR", "SO", "SI", "DLE",
                                                  "DC1", "DC2", "DC3", "DC4", "NAK", "SYN", "ETB", "CAN",
                                                  "EM", "SUB", "ESC", "FS", "GS", "RS", "US", "DEL"}
                    If text <> 127 Then
                        decode = controlchr(text)
                    Else
                        decode = controlchr(32)
                    End If
                Else
                    decode = Chr(text)
                End If
        End Select
        Return decode
    End Function

    Private Sub DecimalChange_Click(sender As Object, e As EventArgs) Handles DecimalChange.Click
        DecimalForm.Show()
        Reload()
        Me.Hide()
    End Sub
    Sub Reload()
        LeftText.Text = ""
        LeftTextBox.Text = ""
        RightText.Text = ""
        RightTextBox.Text = ""
    End Sub
End Class