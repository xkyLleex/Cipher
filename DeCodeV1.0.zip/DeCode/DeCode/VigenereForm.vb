﻿Public Class VigenereForm
    Private Sub VigenereForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Environment.Exit(Environment.ExitCode)
        Application.Exit()
    End Sub
    Private Sub ASCIICode_Click(sender As Object, e As EventArgs) Handles ASCIICode.Click
        ASCIIForm.Show()
        Me.Hide()
    End Sub

    Private Sub BaseCode_Click(sender As Object, e As EventArgs) Handles BaseCode.Click
        BaseForm.Show()
        Me.Hide()
    End Sub

    Private Sub ROTCode_Click(sender As Object, e As EventArgs) Handles ROTCode.Click
        ROTForm.Show()
        Me.Hide()
    End Sub

    Private Sub CaesarCode_Click(sender As Object, e As EventArgs) Handles CaesarCode.Click
        CaesarForm.Show()
        Me.Hide()
    End Sub

    Private Sub Author_Click(sender As Object, e As EventArgs) Handles Author.Click
        AuthorForm.Show()
        Me.Hide()
    End Sub

    Private Sub Firsttop_Click(sender As Object, e As EventArgs) Handles Firsttop.Click
        FirstForm.Show()
        Me.Hide()
    End Sub

    Private Sub DecimalToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DecimalToolStripMenuItem.Click
        DecimalForm.Show()
        Me.Hide()
    End Sub

    Private Sub Decode_Click(sender As Object, e As EventArgs) Handles Decode.Click
        DeCodeForm.Show()
        Me.Hide()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        System.Diagnostics.Process.Start("https://zh.wikipedia.org/wiki/维吉尼亚密码")
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        System.Diagnostics.Process.Start("https://en.wikipedia.org/wiki/Vigen%C3%A8re_cipher")
    End Sub
End Class