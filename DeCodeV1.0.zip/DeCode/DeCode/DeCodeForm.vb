﻿Public Class DeCodeForm
    Dim hash As Boolean
    Private Sub DeCodeForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Environment.Exit(Environment.ExitCode)
        Application.Exit()
    End Sub
    Private Sub DeCodeForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reload()
    End Sub
    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        Select Case ListBox1.Text
            Case "Base32(RCF4648)"
                encode.Enabled = True
                decode.Enabled = True
                key.Enabled = False
                keytext.Text = ""
                Label1.Text = "Base32"
                Label2.Text = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
                Label3.Text = ""
                encode.Text = "Encode"
                hash = False
            Case "Base64"
                encode.Enabled = True
                decode.Enabled = True
                key.Enabled = False
                keytext.Text = ""
                Label1.Text = ListBox1.Text
                Label2.Text = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
                Label3.Text = ""
                encode.Text = "Encode"
                hash = False
            Case "ROT13"
                encode.Enabled = False
                decode.Enabled = True
                key.Enabled = False
                keytext.Text = ""
                Label1.Text = ListBox1.Text
                Label2.Text = "A B C D E F G H I J K L M"
                Label3.Text = "N O P Q R S T U V W X Y Z"
                encode.Text = "Encode"
                hash = False
            Case "ROT18"
                encode.Enabled = False
                decode.Enabled = True
                key.Enabled = False
                keytext.Text = ""
                Label1.Text = ListBox1.Text
                Label2.Text = "A B C D E F G H I J K L M N O P Q R"
                Label3.Text = "S T U V W X Y Z 0 1 2 3 4 5 6 7 8 9"
                encode.Text = "Encode"
                hash = False
            Case "ROT47"
                encode.Enabled = False
                decode.Enabled = True
                key.Enabled = False
                keytext.Text = ""
                Label1.Text = ListBox1.Text
                Label2.Text = "! " + Chr(34) + " # $ % & ' ( ) * + , - . / 0 1 2 3 4 5 6 7 8 9 : ; < = > ? @ A B C D E F G H I J K L M N O"
                Label3.Text = "P Q R S T U V W X Y Z [ \ ] ^ _ ` a b c d e f g h i j k l m n o p q r s t u v w x y z { | } ~"
                encode.Text = "Encode"
                hash = False
            Case "Caesar Cipher"
                encode.Enabled = True
                decode.Enabled = True
                keytext.Text = "請輸入偏移量(右移)*數字*"
                key.Enabled = True
                Label1.Text = "Caesar"
                Label2.Text = "!!!注意：非英文會保留!!!"
                Label3.Text = ""
                encode.Text = "Encode"
                hash = False
            Case "Vigenere Cipher"
                encode.Enabled = True
                decode.Enabled = True
                keytext.Text = "密鑰(只能是英文的)"
                key.Enabled = True
                Label1.Text = "Vigenere"
                Label2.Text = ""
                Label3.Text = ""
                encode.Text = "Encode"
                hash = False
            Case "SHA-1"
                Label1.Text = "SHA-1"
                Forhash()
            Case "SHA-2 SHA256"
                Label1.Text = "SHA-2 SHA256"
                Forhash()
            Case "SHA-2 SHA384"
                Label1.Text = "SHA-2 SHA384"
                Forhash()
            Case "SHA-2 SHA512"
                Label1.Text = "SHA-2 SHA512"
                Forhash()
            Case "MD5"
                Label1.Text = "MD5"
                Forhash()
        End Select
        code.Enabled = True
        key.Text = ""
    End Sub

    Sub Forhash()
        encode.Enabled = True
        decode.Enabled = False
        key.Enabled = False
        keytext.Text = ""
        Label2.Text = ""
        Label3.Text = ""
        encode.Text = "Hash"
        hash = True
    End Sub

    Private Sub Encode_Click(sender As Object, e As EventArgs) Handles encode.Click
        If code.Text <> "" Or hash = True Then
            Select Case Label1.Text
                Case "Base32"
                    Try
                        showcode.Text = EncodeBase32(code.Text)
                    Catch ex As Exception
                        showcode.Text = ex.Message
                    End Try
                Case "Base64"
                    Try
                        showcode.Text = EncodeBase64(code.Text)
                    Catch ex As Exception
                        showcode.Text = ex.Message
                    End Try
                Case "Caesar"
                    If key.Text <> "" Then
                        Try
                            Dim intkey As Integer = key.Text
                            showcode.Text = CaesarEncode(code.Text, intkey)
                        Catch ex As Exception
                            showcode.Text = ex.Message
                        End Try
                    Else
                        MsgBox("請輸入偏移量(右移)進去！", vbOKOnly, "System")
                        showcode.Text = "請輸入偏移量(右移)進去！"
                    End If
                Case "Vigenere"
                    If key.Text <> "" Then
                        Try
                            showcode.Text = VigenereEncode(code.Text, key.Text)
                        Catch ex As Exception
                            showcode.Text = ex.Message
                        End Try
                    Else
                        MsgBox("請輸入key進去！", vbOKOnly, "System")
                        showcode.Text = "請輸入key進去！"
                    End If
                Case "SHA-1"
                    Try
                        showcode.Text = GetSHA1Hash(code.Text)
                    Catch ex As Exception
                        showcode.Text = ex.Message
                    End Try
                Case "SHA-2 SHA256"
                    Try
                        showcode.Text = GetSHA256Hash(code.Text)
                    Catch ex As Exception
                        showcode.Text = ex.Message
                    End Try
                Case "SHA-2 SHA384"
                    Try
                        showcode.Text = GetSHA384Hash(code.Text)
                    Catch ex As Exception
                        showcode.Text = ex.Message
                    End Try
                Case "SHA-2 SHA512"
                    Try
                        showcode.Text = GetSHA512Hash(code.Text)
                    Catch ex As Exception
                        showcode.Text = ex.Message
                    End Try
                Case "MD5"
                    Try
                        showcode.Text = GetMD5Hash(code.Text)
                    Catch ex As Exception
                        showcode.Text = ex.Message
                    End Try
            End Select
        Else
            MsgBox("請輸入code進去！", vbOKOnly, "System")
        End If
    End Sub

    Private Sub Decode_Click(sender As Object, e As EventArgs) Handles decode.Click
        If code.Text <> "" Then
            Select Case Label1.Text
                Case "Base32"
                    Try
                        showcode.Text = DecodeBase32(code.Text)
                    Catch ex As Exception
                        showcode.Text = ex.Message
                    End Try
                Case "Base64"
                    Try
                        showcode.Text = DecodeBase64(code.Text)
                    Catch ex As Exception
                        showcode.Text = ex.Message
                    End Try
                Case "ROT13"
                    Try
                        showcode.Text = Rot13(code.Text)
                    Catch ex As Exception
                        showcode.Text = ex.Message
                    End Try
                Case "ROT18"
                    Try
                        showcode.Text = Rot18(code.Text)
                    Catch ex As Exception
                        showcode.Text = ex.Message
                    End Try
                Case "ROT47"
                    Try
                        showcode.Text = Rot47(code.Text)
                    Catch ex As Exception
                        showcode.Text = ex.Message
                    End Try
                Case "Caesar"
                    Try
                        Dim intkey As Integer = key.Text
                        showcode.Text = CaesarDecode(code.Text, intkey)
                    Catch ex As Exception
                        showcode.Text = ex.Message
                    End Try
                Case "Vigenere"
                    Try
                        showcode.Text = VigenereDecode(code.Text, key.Text)
                    Catch ex As Exception
                        showcode.Text = ex.Message
                    End Try
            End Select
        Else
            MsgBox("請輸入code進去！", vbOKOnly, "System")
        End If
    End Sub

    Function EncodeBase64(ByVal str As String) As String 'Encode base64
        Dim encodestr As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/" '0-63
        Label2.Text = encodestr
        Dim binary As String = ""
        Dim tobinarybase64 As String = ""
        Dim finallyencode As String = ""
        Dim numcount As Integer = 0
        For count As Integer = 0 To str.Length - 1
            If Convert.ToString(Asc(str(count)), 2).Length = 8 Then
                binary = binary + Convert.ToString(Asc(str(count)), 2)
            Else
                For pluszero As Integer = 1 To 8 - Convert.ToString(Asc(str(count)), 2).Length
                    binary = binary + "0"
                Next
                binary = binary + Convert.ToString(Asc(str(count)), 2)
            End If
        Next
        numcount = (binary.Length - binary.Length Mod 6) / 6
        If binary.Length Mod 6 <> 0 Then
            numcount += 1
        End If
        While True
            If binary.Length Mod 8 = 0 And binary.Length Mod 6 = 0 Then
                Exit While
            Else
                binary = binary + "0"
            End If
        End While
        For count As Integer = 0 To binary.Length - 1
            tobinarybase64 = tobinarybase64 + binary(count)
            If numcount = 0 And binary(count) = "0" Then
                If tobinarybase64 = "000000" Then
                    finallyencode = finallyencode + "="
                    tobinarybase64 = ""
                    Continue For
                End If
            End If
            If tobinarybase64.Length = 6 Then
                numcount -= 1
                finallyencode = finallyencode + encodestr(Convert.ToInt32(tobinarybase64, 2))
                tobinarybase64 = ""
            End If
        Next
        Return finallyencode
    End Function

    Function DecodeBase64(ByVal str As String) As String 'Decode base64
        Dim encodestr As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/" '0-63 "="<=64
        Label2.Text = encodestr
        Dim binary As String = ""
        Dim formbase64tobinary As String = ""
        Dim finallyencode As String = ""
        Dim binarycount As Integer = 0
        For strcount As Integer = 0 To str.Length - 1
            For selectstr As Integer = 0 To encodestr.Length - 1
                If str(strcount) = encodestr(selectstr) Then
                    If Convert.ToString(selectstr, 2).Length = 6 Then
                        formbase64tobinary = formbase64tobinary + Convert.ToString(selectstr, 2)
                    Else
                        For pluszero As Integer = 1 To 6 - Convert.ToString(selectstr, 2).Length
                            formbase64tobinary = formbase64tobinary + "0"
                        Next
                        formbase64tobinary = formbase64tobinary + Convert.ToString(selectstr, 2)
                    End If
                End If
            Next
        Next
        For count As Integer = 0 To formbase64tobinary.Length - 1
            binary = binary + formbase64tobinary(count)
            binarycount += 1
            If binarycount = 8 Then
                finallyencode = finallyencode + Chr(Convert.ToInt32(binary, 2))
                binarycount = 0
                binary = ""
            End If
        Next
        Return finallyencode
    End Function

    Function EncodeBase32(ByVal str As String) As String 'Encode base32
        Dim encodestr As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567" '0-31
        Label2.Text = encodestr
        Dim binary As String = ""
        Dim numcount As Integer = 0
        Dim tobinarybase32 As String = ""
        Dim finallyencode As String = ""
        For count As Integer = 0 To str.Length - 1
            If Convert.ToString(Asc(str(count)), 2).Length = 8 Then
                binary = binary + Convert.ToString(Asc(str(count)), 2)
            Else
                For pluszero As Integer = 1 To 8 - Convert.ToString(Asc(str(count)), 2).Length
                    binary = binary + "0"
                Next
                binary = binary + Convert.ToString(Asc(str(count)), 2)
            End If
        Next
        numcount = (binary.Length - binary.Length Mod 5) / 5
        If binary.Length Mod 5 <> 0 Then
            numcount += 1
        End If
        While True
            If binary.Length Mod 8 = 0 And binary.Length Mod 5 = 0 Then
                Exit While
            Else
                binary = binary + "0"
            End If
        End While
        For count As Integer = 0 To binary.Length - 1
            tobinarybase32 = tobinarybase32 + binary(count)
            If numcount = 0 And binary(count) = "0" Then
                If tobinarybase32 = "00000" Then
                    finallyencode = finallyencode + "="
                    tobinarybase32 = ""
                    Continue For
                End If
            End If
            If tobinarybase32.Length = 5 Then
                numcount -= 1
                finallyencode = finallyencode + encodestr(Convert.ToInt32(tobinarybase32, 2))
                tobinarybase32 = ""
            End If
        Next
        Return finallyencode
    End Function

    Function DecodeBase32(ByVal str As String) As String 'Decode base32
        Dim encodestr As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567" '0-31
        Label2.Text = encodestr
        Dim binary As String = ""
        Dim formbase64tobinary As String = ""
        Dim finallyencode As String = ""
        Dim binarycount As Integer = 0
        For strcount As Integer = 0 To str.Length - 1
            For selectstr As Integer = 0 To encodestr.Length - 1
                If str(strcount) = encodestr(selectstr) Then
                    If Convert.ToString(selectstr, 2).Length = 5 Then
                        formbase64tobinary = formbase64tobinary + Convert.ToString(selectstr, 2)
                    Else
                        For pluszero As Integer = 1 To 5 - Convert.ToString(selectstr, 2).Length
                            formbase64tobinary = formbase64tobinary + "0"
                        Next
                        formbase64tobinary = formbase64tobinary + Convert.ToString(selectstr, 2)
                    End If
                End If
            Next
        Next
        For count As Integer = 0 To formbase64tobinary.Length - 1
            binary = binary + formbase64tobinary(count)
            binarycount += 1
            If binarycount = 8 Then
                finallyencode = finallyencode + Chr(Convert.ToInt32(binary, 2))
                binarycount = 0
                binary = ""
            End If
        Next
        Return finallyencode
    End Function

    Function Rot13(ByVal str As String) As String
        Dim rot13One As String = "ABCDEFGHIJKLMabcdefghijklm"
        Dim rot13Two As String = "NOPQRSTUVWXYZnopqrstuvwxyz"
        Dim decodeword As String = ""
        Dim canchange As Boolean
        For strcount As Integer = 0 To str.Length - 1
            canchange = False
            For rot13count As Integer = 0 To rot13One.Length - 1
                If str(strcount) = rot13One(rot13count) Then
                    decodeword = decodeword + rot13Two(rot13count)
                    canchange = True
                    Exit For
                End If
            Next
            If canchange = False Then
                For rot13count As Integer = 0 To rot13Two.Length - 1
                    If str(strcount) = rot13Two(rot13count) Then
                        decodeword = decodeword + rot13One(rot13count)
                        canchange = True
                        Exit For
                    End If
                Next
            End If
            If canchange = False Then
                decodeword = decodeword + str(strcount)
            End If
        Next
        Return decodeword
    End Function

    Function Rot18(ByVal str As String) As String
        Dim rot18One As String = "ABCDEFGHIJKLMNOPQRabcdefghijklmnopqr"
        Dim rot18Two As String = "STUVWXYZ0123456789stuvwxyz0123456789"
        Dim decodeword As String = ""
        Dim canchange As Boolean
        For strcount As Integer = 0 To str.Length - 1
            canchange = False
            For rot18count As Integer = 0 To rot18One.Length - 1
                If str(strcount) = rot18One(rot18count) Then
                    decodeword = decodeword + rot18Two(rot18count)
                    canchange = True
                    Exit For
                End If
            Next
            If canchange = False Then
                For rot18count As Integer = 0 To rot18Two.Length - 1
                    If str(strcount) = rot18Two(rot18count) Then
                        decodeword = decodeword + rot18One(rot18count)
                        canchange = True
                        Exit For
                    End If
                Next
            End If
            If canchange = False Then
                decodeword = decodeword + str(strcount)
            End If
        Next
        Return decodeword
    End Function

    Function Rot47(ByVal str As String) As String
        Dim rot47One As String = "!" + Chr(34) + "#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNO"
        Dim rot47Two As String = "PQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~"
        Dim decodeword As String = ""
        Dim canchange As Boolean
        For strcount As Integer = 0 To str.Length - 1
            canchange = False
            For rot47count As Integer = 0 To rot47One.Length - 1
                If str(strcount) = rot47One(rot47count) Then
                    decodeword = decodeword + rot47Two(rot47count)
                    canchange = True
                    Exit For
                End If
            Next
            If canchange = False Then
                For rot47count As Integer = 0 To rot47Two.Length - 1
                    If str(strcount) = rot47Two(rot47count) Then
                        decodeword = decodeword + rot47One(rot47count)
                        canchange = True
                        Exit For
                    End If
                Next
            End If
            If canchange = False Then
                decodeword = decodeword + str(strcount)
            End If
        Next
        Return decodeword
    End Function

    Function CaesarDecode(ByVal str As String, ByVal movekey As Integer) As String
        Dim encode As String = ""
        If movekey > 25 Then
            movekey = movekey Mod 26
        End If
        For strcount As Integer = 0 To str.Length - 1
            Dim movenum As Integer = Asc(str(strcount)) - movekey
            If (91 > Asc(str(strcount)) And Asc(str(strcount)) > 64) Or (123 > Asc(str(strcount)) And Asc(str(strcount)) > 96) Then
                If (91 > movenum And movenum > 64) Or (123 > movenum And movenum > 96) Then
                    encode = encode + Chr(movenum)
                Else
                    movenum += 26
                    encode = encode + Chr(movenum)
                End If
            Else
                encode = encode + str(strcount)
            End If
        Next
        Return encode
        Return str
    End Function

    Function CaesarEncode(ByVal str As String, ByVal movekey As Integer) As String
        Dim encode As String = ""
        If movekey > 25 Then
            movekey = movekey Mod 26
        End If
        For strcount As Integer = 0 To str.Length - 1
            Dim movenum As Integer = Asc(str(strcount)) + movekey
            If (91 > Asc(str(strcount)) And Asc(str(strcount)) > 64) Or (123 > Asc(str(strcount)) And Asc(str(strcount)) > 96) Then
                If (91 > movenum And movenum > 64) Or (123 > movenum And movenum > 96) Then
                    encode = encode + Chr(movenum)
                Else
                    movenum -= 26
                    encode = encode + Chr(movenum)
                End If
            Else
                encode = encode + str(strcount)
            End If
        Next
        Return encode
    End Function

    Function VigenereDecode(ByVal str As String, ByVal keycode As String) As String
        Dim encodeUpperLower As String = ""
        Dim encode As String = ""
        Dim keycount As Integer = 0
        For strcount As Integer = 0 To str.Length - 1
            If Asc(str(strcount)) > 64 And Asc(str(strcount)) < 91 Then 'Upper
                encodeUpperLower += "U"
            ElseIf Asc(str(strcount)) > 96 And Asc(str(strcount)) < 123 Then 'Lower
                encodeUpperLower += "L"
            Else
                encodeUpperLower += "N"
            End If
        Next
        str = str.ToUpper()
        keycode = keycode.ToUpper()
        For strcount As Integer = 0 To str.Length - 1
            If 91 < Asc(keycode(keycount)) Or Asc(keycode(keycount)) < 64 Then
                Return "密鑰只能是英文的"
            End If
            Dim ans As Integer = Asc(str(strcount)) + 65 - Asc(keycode(keycount))
            If ans < 65 Then
                ans += 26
            End If
            If encodeUpperLower(strcount) = "U" Then
                encode += Chr(ans)
            ElseIf encodeUpperLower(strcount) = "L" Then
                encode += Chr(ans + 32)
            Else
                encode += str(strcount)
                keycount -= 1
            End If
            keycount += 1
            If keycount = keycode.Length Then
                keycount = 0
            End If
        Next
        Return encode
    End Function

    Function VigenereEncode(ByVal str As String, ByVal keycode As String) As String
        Dim encodeUpperLower As String = ""
        Dim encode As String = ""
        Dim keycount As Integer = 0
        For strcount As Integer = 0 To str.Length - 1
            If Asc(str(strcount)) > 64 And Asc(str(strcount)) < 91 Then 'Upper
                encodeUpperLower += "U"
            ElseIf Asc(str(strcount)) > 96 And Asc(str(strcount)) < 123 Then 'Lower
                encodeUpperLower += "L"
            Else
                encodeUpperLower += "N"
            End If
        Next
        str = str.ToUpper()
        keycode = keycode.ToUpper()
        For strcount As Integer = 0 To str.Length - 1
            If 91 < Asc(keycode(keycount)) Or Asc(keycode(keycount)) < 64 Then
                Return "密鑰只能是英文的"
            End If
            Dim ans As Integer = Asc(str(strcount)) + Asc(keycode(keycount)) - 65
            If ans > 90 Then
                ans -= 26
            End If
            If encodeUpperLower(strcount) = "U" Then
                encode += Chr(ans)
            ElseIf encodeUpperLower(strcount) = "L" Then
                encode += Chr(ans + 32)
            Else
                encode += str(strcount)
                keycount -= 1
            End If
            keycount += 1
            If keycount = keycode.Length Then
                keycount = 0
            End If
        Next
        Return encode
    End Function

    Function GetSHA1Hash(ByVal strToHash As String) As String
        Dim sha1Obj As New Security.Cryptography.SHA1CryptoServiceProvider
        Dim bytesToHash() As Byte = System.Text.Encoding.ASCII.GetBytes(strToHash)
        bytesToHash = sha1Obj.ComputeHash(bytesToHash)
        Dim strResult As String = ""
        For Each b As Byte In bytesToHash
            strResult += b.ToString("x2")
        Next
        Return strResult
    End Function

    Function GetSHA256Hash(ByVal strToHash As String) As String
        Dim sha1Obj As New Security.Cryptography.SHA256CryptoServiceProvider
        Dim bytesToHash() As Byte = System.Text.Encoding.ASCII.GetBytes(strToHash)
        bytesToHash = sha1Obj.ComputeHash(bytesToHash)
        Dim strResult As String = ""
        For Each b As Byte In bytesToHash
            strResult += b.ToString("x2")
        Next
        Return strResult
    End Function

    Function GetSHA384Hash(ByVal strToHash As String) As String
        Dim sha1Obj As New Security.Cryptography.SHA384CryptoServiceProvider
        Dim bytesToHash() As Byte = System.Text.Encoding.ASCII.GetBytes(strToHash)
        bytesToHash = sha1Obj.ComputeHash(bytesToHash)
        Dim strResult As String = ""
        For Each b As Byte In bytesToHash
            strResult += b.ToString("x2")
        Next
        Return strResult
    End Function

    Function GetSHA512Hash(ByVal strToHash As String) As String
        Dim sha1Obj As New Security.Cryptography.SHA512CryptoServiceProvider
        Dim bytesToHash() As Byte = System.Text.Encoding.ASCII.GetBytes(strToHash)
        bytesToHash = sha1Obj.ComputeHash(bytesToHash)
        Dim strResult As String = ""
        For Each b As Byte In bytesToHash
            strResult += b.ToString("x2")
        Next
        Return strResult
    End Function

    Function GetMD5Hash(ByVal strToHash As String) As String
        Dim sha1Obj As New Security.Cryptography.MD5CryptoServiceProvider
        Dim bytesToHash() As Byte = System.Text.Encoding.ASCII.GetBytes(strToHash)
        bytesToHash = sha1Obj.ComputeHash(bytesToHash)
        Dim strResult As String = ""
        For Each b As Byte In bytesToHash
            strResult += b.ToString("x2")
        Next
        Return strResult
    End Function

    Private Sub Firsttop_Click(sender As Object, e As EventArgs) Handles firsttop.Click
        FirstForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Author_Click(sender As Object, e As EventArgs) Handles Author.Click
        AuthorForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub ASCIICode_Click(sender As Object, e As EventArgs) Handles ASCIICode.Click
        ASCIIForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub BaseCode_Click(sender As Object, e As EventArgs) Handles BaseCode.Click
        BaseForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub ROTCode_Click(sender As Object, e As EventArgs) Handles ROTCode.Click
        ROTForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub CaesarCode_Click(sender As Object, e As EventArgs) Handles CaesarCode.Click
        CaesarForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub VigenereCode_Click(sender As Object, e As EventArgs) Handles VigenereCode.Click
        VigenereForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub DecimalChange_Click(sender As Object, e As EventArgs) Handles DecimalChange.Click
        DecimalForm.Show()
        Reload()
        Me.Hide()
    End Sub
    Sub Reload()
        Label1.Text = ""
        Label2.Text = "請選擇左邊的加/解密方式"
        Label3.Text = ""
        code.Text = ""
        decode.Enabled = False
        encode.Enabled = False
        code.Enabled = False
        keytext.Text = ""
        key.Enabled = False
    End Sub
End Class