﻿Public Class DecimalForm
    Dim leftbarvalue, rightbarvalue As Integer
    Private Sub DecimalForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Environment.Exit(Environment.ExitCode)
        Application.Exit()
    End Sub
    Private Sub ASCIICode_Click(sender As Object, e As EventArgs) Handles ASCIICode.Click
        ASCIIForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub BaseCode_Click(sender As Object, e As EventArgs) Handles BaseCode.Click
        BaseForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub ROTCode_Click(sender As Object, e As EventArgs) Handles ROTCode.Click
        ROTForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub CaesarCode_Click(sender As Object, e As EventArgs) Handles CaesarCode.Click
        CaesarForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub VigenereCode_Click(sender As Object, e As EventArgs) Handles VigenereCode.Click
        VigenereForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Decode_Click(sender As Object, e As EventArgs) Handles Decode.Click
        DeCodeForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Author_Click(sender As Object, e As EventArgs) Handles Author.Click
        AuthorForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Firsttop_Click(sender As Object, e As EventArgs) Handles Firsttop.Click
        FirstForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        System.Diagnostics.Process.Start("https://en.wikipedia.org/wiki/Decimal")
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        System.Diagnostics.Process.Start("https://zh.wikipedia.org/wiki/%E8%BF%9B%E4%BD%8D%E5%88%B6")
    End Sub
    Private Sub DecimalForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reload()
    End Sub

    Private Sub LeftBar_Scroll(sender As Object, e As EventArgs) Handles LeftBar.Scroll
        leftbarvalue = LeftBar.Value
        If leftbarvalue <> 4 Then
            LeftDecimal.Enabled = False
            If leftbarvalue = 3 Then
                LeftDecimal.Text = 16
            ElseIf leftbarvalue = 2 Then
                LeftDecimal.Text = 10
            ElseIf leftbarvalue = 1 Then
                LeftDecimal.Text = 8
            Else
                LeftDecimal.Text = 2
            End If
        Else
            LeftDecimal.Enabled = True
        End If
    End Sub

    Private Sub RightBar_Scroll(sender As Object, e As EventArgs) Handles RightBar.Scroll
        rightbarvalue = RightBar.Value
        If rightbarvalue <> 4 Then
            RightDecimal.Enabled = False
            If rightbarvalue = 3 Then
                RightDecimal.Text = 16
            ElseIf rightbarvalue = 2 Then
                RightDecimal.Text = 10
            ElseIf rightbarvalue = 1 Then
                RightDecimal.Text = 8
            Else
                RightDecimal.Text = 2
            End If
        Else
            RightDecimal.Enabled = True
        End If
    End Sub

    Private Sub Change_Click(sender As Object, e As EventArgs) Handles Change.Click
        If LeftDecimal.Text <> "" And RightDecimal.Text <> "" Then
            If LeftTextBox.Text = "" Then
                MsgBox("請輸入Code進去", vbOKOnly, "System")
            Else
                Try
                    Dim leftnum As Integer = LeftDecimal.Text
                    Dim rightnum As Integer = RightDecimal.Text
                    If leftnum > 1 And leftnum < 37 And rightnum > 1 And rightnum < 37 Then
                        Dim changenum As Integer = Changetoten(LeftTextBox.Text, leftnum)
                        If changenum <> -1 Then
                            RightTextBox.Text = Tenchangetoany(changenum, rightnum)
                        Else
                            RightTextBox.Text = "Error"
                        End If
                    Else
                        MsgBox("無法轉換值" & vbCrLf & "(只能轉換2-36進制)", vbOKOnly, "System")
                    End If
                Catch ex As Exception
                    RightTextBox.Text = ex.Message
                    MsgBox(ex.Message, vbOKOnly, "System")
                End Try
            End If
        Else
            MsgBox("請輸入進位值(兩邊都要)", vbOKOnly, "System")
        End If

    End Sub
    Function Changetoten(ByVal str As String, ByVal num As Integer) As Integer
        Dim finalten As Integer = 0
        For multiply As Integer = 1 To str.Length
            Dim midcount As Integer = 1
            For count As Integer = 1 To str.Length - multiply
                midcount *= num
            Next
            If Asc(str(multiply - 1)) > 47 And Asc(str(multiply - 1)) <58 Then
                If num > (Asc(str(multiply - 1)) - 48) Then
                    finalten += (Asc(str(multiply - 1)) - 48) * midcount
                Else
                    MsgBox("資料錯誤(" & num & "轉換錯誤)" & vbCrLf & "可能原因為:輸入值錯誤", vbOKOnly, "System")
                    Return -1
                End If
            ElseIf Asc(str(multiply - 1)) > 64 And Asc(str(multiply - 1)) < 91 Then
                If num > (Asc(str(multiply - 1)) - 55) Then
                    finalten += (Asc(str(multiply - 1)) - 55) * midcount
                Else
                    MsgBox("資料錯誤(" & num & "轉換錯誤)" & vbCrLf & "可能原因為:輸入值錯誤", vbOKOnly, "System")
                    Return -1
                End If
            ElseIf Asc(str(multiply - 1)) > 96 And Asc(str(multiply - 1)) < 123 Then
                If num > (Asc(str(multiply - 1)) - 87) Then
                    finalten += (Asc(str(multiply - 1)) - 87) * midcount
                Else
                    MsgBox("資料錯誤(" & num & "轉換錯誤)" & vbCrLf & "可能原因為:輸入值錯誤", vbOKOnly, "System")
                    Return -1
                End If
            End If
        Next
        Return finalten
    End Function
    Function Tenchangetoany(ByVal str As Integer, ByVal num As Integer) As String 'str 10
        Dim finalnum As String = ""
        Dim midcount As Integer = 1
        If num <> 10 Then
            While True
                If str < num Then
                    If num > 10 Then ' <10 decimal
                        If str Mod num > 9 Then ' 65--A
                            finalnum = Chr((str Mod num) + 55) + finalnum
                        Else
                            finalnum = (str Mod num).ToString + finalnum
                        End If
                    Else '  >10 decimal
                        finalnum = (str Mod num).ToString + finalnum
                    End If
                    Exit While
                Else
                    If num > 10 Then ' <10 decimal
                        If str Mod num > 9 Then ' 65--A
                            finalnum = Chr((str Mod num) + 55) + finalnum
                        Else
                            finalnum = (str Mod num).ToString + finalnum
                        End If
                    Else '  >10 decimal
                        finalnum = (str Mod num).ToString + finalnum
                    End If
                    If str Mod num = 0 Then
                        str = str / num
                    Else
                        str = (str - (str Mod num)) / num
                    End If
                End If
            End While
        Else
            Return str
        End If
        Return finalnum
    End Function
    Sub Reload()
        LeftBar.Value = 4
        RightBar.Value = 4
        RightDecimal.Enabled = True
        RightDecimal.Enabled = True
        LeftTextBox.Text = ""
        RightTextBox.Text = ""
        LeftDecimal.Text = ""
        RightDecimal.Text = ""
    End Sub
End Class