﻿Public Class BaseForm
    Dim base64 As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    Dim base32 As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
    Private Sub BaseForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Environment.Exit(Environment.ExitCode)
        Application.Exit()
    End Sub
    Private Sub ASCIICode_Click(sender As Object, e As EventArgs) Handles ASCIICode.Click
        ASCIIForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub ROTCode_Click(sender As Object, e As EventArgs) Handles ROTCode.Click
        ROTForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub CaesarCode_Click(sender As Object, e As EventArgs) Handles CaesarCode.Click
        CaesarForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub VigenereCode_Click(sender As Object, e As EventArgs) Handles VigenereCode.Click
        VigenereForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Author_Click(sender As Object, e As EventArgs) Handles Author.Click
        AuthorForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Firsttop_Click(sender As Object, e As EventArgs) Handles Firsttop.Click
        FirstForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Decode_Click(sender As Object, e As EventArgs) Handles Decode.Click
        DeCodeForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub DecimalChange_Click(sender As Object, e As EventArgs) Handles DecimalChange.Click
        DecimalForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        System.Diagnostics.Process.Start("https://en.wikipedia.org/wiki/Base64")
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        System.Diagnostics.Process.Start("https://en.wikipedia.org/wiki/Base32")
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            CheckBox2.Checked = False
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            CheckBox1.Checked = False
        End If
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        helptext.Text = ""
        If CheckBox1.Checked = True Then 'base64
            Try
                Dim num As Integer = TextBox4.Text
                If num >= 0 And num < 64 Then
                    TextBox3.Text = base64(num)
                Else
                    helptext.Text = "錯誤數值！"
                End If
            Catch ex As Exception
                helptext.Text = "只能輸入數值！"
            End Try
        ElseIf CheckBox2.Checked = True Then 'base32
            Try
                Dim num As Integer = TextBox4.Text
                If num >= 0 And num < 32 Then
                    TextBox3.Text = base32(num)
                Else
                    helptext.Text = "錯誤數值！"
                End If
            Catch ex As Exception
                helptext.Text = "只能輸入數值！"
            End Try
        End If
    End Sub

    Private Sub BaseForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reload()
    End Sub

    Sub Reload()
        helptext.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        CheckBox1.Checked = False
        CheckBox2.Checked = False
    End Sub
End Class