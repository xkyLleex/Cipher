﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class VigenereForm
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請勿使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(VigenereForm))
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.Firsttop = New System.Windows.Forms.ToolStripMenuItem()
        Me.Decode = New System.Windows.Forms.ToolStripMenuItem()
        Me.Author = New System.Windows.Forms.ToolStripMenuItem()
        Me.allcode = New System.Windows.Forms.ToolStripMenuItem()
        Me.DecimalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ASCIICode = New System.Windows.Forms.ToolStripMenuItem()
        Me.BaseCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.ROTCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.CaesarCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.VigenereCode = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.MenuStrip2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Firsttop, Me.Decode, Me.Author, Me.allcode})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(584, 24)
        Me.MenuStrip2.TabIndex = 4
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'Firsttop
        '
        Me.Firsttop.Name = "Firsttop"
        Me.Firsttop.Size = New System.Drawing.Size(43, 20)
        Me.Firsttop.Text = "首頁"
        '
        'Decode
        '
        Me.Decode.Name = "Decode"
        Me.Decode.Size = New System.Drawing.Size(72, 20)
        Me.Decode.Text = "編碼/解碼"
        '
        'Author
        '
        Me.Author.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.Author.Name = "Author"
        Me.Author.Size = New System.Drawing.Size(43, 20)
        Me.Author.Text = "作者"
        '
        'allcode
        '
        Me.allcode.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DecimalToolStripMenuItem, Me.ASCIICode, Me.BaseCode, Me.ROTCode, Me.CaesarCode, Me.VigenereCode})
        Me.allcode.Name = "allcode"
        Me.allcode.Size = New System.Drawing.Size(67, 20)
        Me.allcode.Text = "各碼解析"
        '
        'DecimalToolStripMenuItem
        '
        Me.DecimalToolStripMenuItem.Name = "DecimalToolStripMenuItem"
        Me.DecimalToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.DecimalToolStripMenuItem.Text = "Decimal"
        '
        'ASCIICode
        '
        Me.ASCIICode.Name = "ASCIICode"
        Me.ASCIICode.Size = New System.Drawing.Size(165, 22)
        Me.ASCIICode.Text = "ASCII code"
        '
        'BaseCode
        '
        Me.BaseCode.Name = "BaseCode"
        Me.BaseCode.Size = New System.Drawing.Size(165, 22)
        Me.BaseCode.Text = "Base code"
        '
        'ROTCode
        '
        Me.ROTCode.Name = "ROTCode"
        Me.ROTCode.Size = New System.Drawing.Size(165, 22)
        Me.ROTCode.Text = "ROT code"
        '
        'CaesarCode
        '
        Me.CaesarCode.Name = "CaesarCode"
        Me.CaesarCode.Size = New System.Drawing.Size(165, 22)
        Me.CaesarCode.Text = "Caesar Cipher"
        '
        'VigenereCode
        '
        Me.VigenereCode.Name = "VigenereCode"
        Me.VigenereCode.Size = New System.Drawing.Size(165, 22)
        Me.VigenereCode.Text = "Vigenere Cipher"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(133, 29)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Vigenere"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.Location = New System.Drawing.Point(161, 36)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(113, 14)
        Me.LinkLabel1.TabIndex = 9
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Vigenere-tw-wiki"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel2.Location = New System.Drawing.Point(319, 36)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(113, 14)
        Me.LinkLabel2.TabIndex = 10
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Vigenere-en-wiki"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 56)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(300, 300)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 11
        Me.PictureBox1.TabStop = False
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("標楷體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(319, 56)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(253, 300)
        Me.TextBox1.TabIndex = 12
        Me.TextBox1.Text = resources.GetString("TextBox1.Text")
        '
        'VigenereForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(584, 361)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.LinkLabel2)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.MenuStrip2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "VigenereForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cipher v1.0"
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip2 As MenuStrip
    Friend WithEvents Firsttop As ToolStripMenuItem
    Friend WithEvents Decode As ToolStripMenuItem
    Friend WithEvents Author As ToolStripMenuItem
    Friend WithEvents allcode As ToolStripMenuItem
    Friend WithEvents ASCIICode As ToolStripMenuItem
    Friend WithEvents BaseCode As ToolStripMenuItem
    Friend WithEvents ROTCode As ToolStripMenuItem
    Friend WithEvents CaesarCode As ToolStripMenuItem
    Friend WithEvents VigenereCode As ToolStripMenuItem
    Friend WithEvents Label2 As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents LinkLabel2 As LinkLabel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents DecimalToolStripMenuItem As ToolStripMenuItem
End Class
