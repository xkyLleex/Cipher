﻿Public Class CaesarForm
    Dim num As Integer
    Private Sub CaesarForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Environment.Exit(Environment.ExitCode)
        Application.Exit()
    End Sub
    Private Sub DecimalToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DecimalToolStripMenuItem.Click
        DecimalForm.Show()
        Reload()
        Me.Hide()
    End Sub
    Private Sub Author_Click(sender As Object, e As EventArgs) Handles Author.Click
        AuthorForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub ASCIICode_Click(sender As Object, e As EventArgs) Handles ASCIICode.Click
        ASCIIForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub BaseCode_Click(sender As Object, e As EventArgs) Handles BaseCode.Click
        BaseForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub ROTCode_Click(sender As Object, e As EventArgs) Handles ROTCode.Click
        ROTForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub VigenereCode_Click(sender As Object, e As EventArgs) Handles VigenereCode.Click
        VigenereForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Firsttop_Click(sender As Object, e As EventArgs) Handles Firsttop.Click
        FirstForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub Decode_Click(sender As Object, e As EventArgs) Handles Decode.Click
        DeCodeForm.Show()
        Reload()
        Me.Hide()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        System.Diagnostics.Process.Start("https://zh.wikipedia.org/wiki/%E5%87%B1%E6%92%92%E5%AF%86%E7%A2%BC")
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        System.Diagnostics.Process.Start("https://en.wikipedia.org/wiki/Caesar_cipher")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Label5.Text = ""
        TextBox2.Text = ""
        Dim checknum As Boolean = False
        Dim text As String = ""
        Dim rightmove As Integer
        If TextBox1.Text = "" Then
            Label5.Text = "請定義字串行"
        Else
            Try
                If TextBox3.Text = "" Then
                    Label5.Text = "請輸入數字進去！"
                    checknum = True
                Else
                    rightmove = TextBox3.Text
                End If
            Catch ex As Exception
                Label5.Text = "只能輸入數字！"
                checknum = True
            End Try
            If checknum = False Then
                rightmove = rightmove Mod TextBox1.Text.Length
                For count As Integer = 1 To TextBox1.Text.Length
                    text += TextBox1.Text(rightmove)
                    If rightmove = TextBox1.Text.Length - 1 Then 'ABC BCA
                        rightmove = 0
                    Else
                        rightmove += 1
                    End If
                Next
                TextBox2.Text = text
            End If
            TextBox3.Text = ""
        End If
    End Sub

    Private Sub CaesarForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reload()
    End Sub
    Sub Reload()
        Label5.Text = ""
        TextBox2.Text = ""
        num = 0
        Label6.Text = ""
        TextBox1.ReadOnly = True
        TextBox1.Text = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            TextBox1.ReadOnly = False
        Else
            TextBox1.ReadOnly = True
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click
        num += 1
        Select Case num
            Case 1
                Label6.Text = "看什麼看，沒看過帥哥？"
            Case 2
                Label6.Text = "可以不要點了嗎？"
            Case 3
                Label6.Text = "你在點我打你喔！"
            Case 4
                Label6.Text = "不會有驚喜跑出來！"
            Case 5
                Label6.Text = "算了不理你了！"
            Case Else
                Label6.Text = ""
        End Select
    End Sub
End Class